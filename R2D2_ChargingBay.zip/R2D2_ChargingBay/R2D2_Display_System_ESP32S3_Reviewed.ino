// ============================================================
// R2-D2 COMPLETE DISPLAY SYSTEM
// ============================================================
//
// Target controller:
//   Freenove ESP32-S3 WROOM board / ESP32-S3
//
// DISPLAY HARDWARE:
//
//   1. GC9A01 240x240 round TFT display
//   2. HT16K33 8x8 LED matrix
//   3. WS2812B strip/group with 8 LEDs
//   4. WS2812B strip/group with 5 LEDs
//
// ============================================================
// COMPLETE WIRING / PIN CONNECTIONS
// ============================================================
//
// GC9A01 TFT DISPLAY
// ------------------
// TFT VCC  -> ESP32-S3 3.3V
// TFT GND  -> ESP32-S3 GND
// TFT SCL  -> ESP32-S3 GPIO18    (SPI clock / SCK)
// TFT SDA  -> ESP32-S3 GPIO39    (SPI data / MOSI)
// TFT DC   -> ESP32-S3 GPIO2
// TFT CS   -> ESP32-S3 GPIO15
// TFT RST  -> ESP32-S3 GPIO5
//
// Note:
// On many GC9A01 boards the SPI data pin is labeled SDA rather than MOSI.
// This is NOT I2C SDA; it is the SPI MOSI signal.
//
// HT16K33 8x8 LED MATRIX
// ----------------------
// Matrix VCC -> ESP32-S3 5V
// Matrix GND -> ESP32-S3 GND
// Matrix SDA -> ESP32-S3 GPIO41
// Matrix SCL -> ESP32-S3 GPIO1
//
// I2C address: 0x70
//
// WS2812B - 8 LEDs
// ----------------
// WS8 DIN -> ESP32-S3 GPIO42
// WS8 VCC -> 5V
// WS8 GND -> GND
//
// WS2812B - 5 LEDs
// ----------------
// WS5 DIN -> ESP32-S3 GPIO47
// WS5 VCC -> 5V
// WS5 GND -> GND
//
// IMPORTANT POWER NOTES
// ---------------------
// All devices MUST share a common ground with the ESP32-S3.
//
// The WS2812B LEDs should be powered from a suitable 5V supply.
// Do not power a large LED load from the ESP32 board itself.
//
// ============================================================
// USER-ADJUSTABLE SETTINGS
// ============================================================
//
// WS_LED_BRIGHTNESS:
//   0   = off
//   255 = maximum brightness
//
// Each WS2812 animation mode now has its own speed setting.
// Higher value = faster animation.
// Lower value  = slower animation.
//
// The TFT animation logic and HT16K33 8x8 animation logic are
// otherwise left unchanged.
//
// ============================================================

#include <SPI.h>
#include <Wire.h>

#include <Adafruit_GFX.h>
#include <Adafruit_GC9A01A.h>
#include <Adafruit_LEDBackpack.h>
#include <Adafruit_NeoPixel.h>

#include "Aurebesh8pt7b.h"


// ============================================================
// USER SETTINGS
// ============================================================

// ------------------------------------------------------------
// WS2812B MASTER BRIGHTNESS
// ------------------------------------------------------------
//
// Valid range: 0-255
//
#define WS_LED_BRIGHTNESS 55


// ------------------------------------------------------------
// WS2812B ANIMATION SPEEDS
// ------------------------------------------------------------
//
// Each animation mode can be adjusted independently.
//
// Suggested values:
//   1-2   = very slow
//   3-4   = slow
//   5     = current/default speed
//   6-8   = fast
//   9-12  = very fast
//
// These settings affect ONLY the WS2812B animations.
// The TFT and HT16K33 8x8 matrix timing is not changed.
//
#define WS_SPEED_IDLE_PATTERN  5
#define WS_SPEED_DATA_FLOW     5
#define WS_SPEED_SCANNER       5
#define WS_SPEED_SYSTEM_PULSE  5
#define WS_SPEED_DATA_BURST    5


// ============================================================
// TFT
// ============================================================

#define TFT_SCK  18
#define TFT_MOSI 39
#define TFT_DC   2
#define TFT_CS   15
#define TFT_RST  5

Adafruit_GC9A01A tft(
    TFT_CS,
    TFT_DC,
    TFT_RST
);


// ============================================================
// HT16K33 8x8 MATRIX
// ============================================================

#define I2C_SDA_PIN 41
#define I2C_SCL_PIN 1

#define MATRIX_ADDRESS 0x70

Adafruit_8x8matrix matrix =
    Adafruit_8x8matrix();

#define MATRIX_BRIGHTNESS 5


// ============================================================
// WS2812B
// ============================================================

#define WS8_PIN 42
#define WS5_PIN 47

#define WS8_COUNT 8
#define WS5_COUNT 5


Adafruit_NeoPixel strip8(
    WS8_COUNT,
    WS8_PIN,
    NEO_GRB + NEO_KHZ800
);


Adafruit_NeoPixel strip5(
    WS5_COUNT,
    WS5_PIN,
    NEO_GRB + NEO_KHZ800
);


// ============================================================
// TFT COLORS
// ============================================================

#define COLOR_TACTICAL_BLUE 0x004aff


// ============================================================
// TFT CONFIGURATION
// ============================================================

const int TFT_WIDTH = 240;
const int CENTER = 120;


const int TEXT_LINES[4][2] =
{
    {30, 140},
    {35, 160},
    {44, 180},
    {70, 200}
};


// ============================================================
// TIMER
// ============================================================

typedef struct
{
    unsigned long time_start;
    unsigned long durationMs;

} Timer;


// ============================================================
// TACTICAL DISPLAY ARCS
// ============================================================

const int arcs[5][4] =
{
    {300, 380, 30, 0},
    {300, 380, 30, 0},
    {55, 240, 30, 0},
    {55, 90, 45, 0},
    {180, 380, 45, 0}
};


const int nbrOfArcs = 5;


// ============================================================
// TACTICAL ANGLE LINES
// ============================================================

const int angleLines[6][4] =
{
    {CENTER + 16, CENTER + 18, 67, 55},
    {CENTER + 21, CENTER + 9, 67, 15},
    {CENTER + 21, CENTER - 9, 67, 345},
    {CENTER + 12, CENTER - 18, 67, 295},
    {CENTER - 12, CENTER - 18, 67, 240},
    {CENTER - 19, CENTER - 9, 67, 200}
};


const int nbrAngleLines = 6;


// ============================================================
// DETECTED OBJECTS
// ============================================================

const int detectedObjects[24][5] =
{
    {CENTER - 50, CENTER - 50, 20, 8, 55},
    {CENTER - 40, CENTER - 50, 8, 4, 55},
    {CENTER - 25, CENTER - 50, 20, 9, 60},
    {CENTER - 22, CENTER - 60, 7, 5, 60},
    {CENTER - 5, CENTER - 70, 20, 8, 90},
    {CENTER - 12, CENTER - 70, 8, 5, 90},
    {CENTER + 5, CENTER - 80, 20, 5, 90},
    {CENTER + 10, CENTER - 89, 3, 12, 90},
    {CENTER + 17, CENTER - 75, 8, 8, 105},
    {CENTER + 28, CENTER - 70, 35, 6, 112},
    {CENTER + 40, CENTER - 65, 10, 6, 112},
    {CENTER + 50, CENTER - 68, 15, 6, 117},
    {CENTER + 61, CENTER - 68, 5, 10, 117},
    {CENTER + 68, CENTER - 50, 25, 10, 140},
    {CENTER + 75, CENTER - 40, 6, 7, 150},
    {CENTER + 67, CENTER - 29, 35, 4, 163},
    {CENTER + 75, CENTER - 17, 30, 5, 166},
    {CENTER + 65, CENTER - 6, 10, 8, 180},
    {CENTER + 75, CENTER + 6, 10, 8, 180},
    {CENTER + 85, CENTER + 20, 13, 6, 196},
    {CENTER + 60, CENTER + 25, 60, 4, 196},
    {CENTER + 55, CENTER + 40, 15, 10, 215},
    {CENTER + 60, CENTER + 50, 4, 20, 215},
    {CENTER + 55, CENTER + 60, 14, 4, 238}
};


const int nbrDetectedObjects = 24;


// ============================================================
// UNDETECTED OBJECTS
// ============================================================

const int undetectedObjects[2][5] =
{
    {CENTER - 70, CENTER - 15, 25, 10, 17},
    {CENTER + 25, CENTER + 65, 25, 20, 250}
};


const int nbrUndetectedObjects = 2;


// ============================================================
// OBJECT COLORS
// ============================================================

const int objectsColor[] =
{
    GC9A01A_GREEN,
    GC9A01A_NORON,
    GC9A01A_RED,
    GC9A01A_ORANGE,
    GC9A01A_YELLOW
};


const int objectColorCount = 5;


// ============================================================
// AUREBESH WORDS
// ============================================================

const char *WORDS[] =
{
    "com",
    "radar",
    "track",
    "on"
};


int wordsCount =
    sizeof(WORDS) / sizeof(WORDS[0]);


// ============================================================
// GEOMETRY
// ============================================================

const int num_degrees = 381;


struct Coordinate
{
    byte x;
    byte y;
};


// ============================================================
// 8x8 ANIMATION MODES
// ============================================================

enum class AnimationMode
{
    IDLE_PATTERN,
    DATA_FLOW,
    SCANNER,
    SYSTEM_PULSE,
    DATA_BURST
};


AnimationMode currentMode =
    AnimationMode::IDLE_PATTERN;


// ============================================================
// ANIMATION TIMING
// ============================================================

unsigned long lastFrameTime = 0;
unsigned long modeStartTime = 0;

uint16_t frameInterval = 120;
uint16_t modeDuration = 3000;

uint8_t animationFrame = 0;


// ============================================================
// WS2812 TIMING
// ============================================================

unsigned long lastLedUpdate = 0;

const uint16_t LED_UPDATE_INTERVAL = 20;

uint32_t ledAnimationTime = 0;


// ============================================================
// IDLE MATRIX PATTERNS
// ============================================================

const uint8_t idlePattern1[8] =
{
    B00010000,
    B01000010,
    B00000100,
    B00110000,
    B00000001,
    B10000100,
    B00001000,
    B00100010
};


const uint8_t idlePattern2[8] =
{
    B00000010,
    B00100000,
    B10001000,
    B00000001,
    B01000100,
    B00010000,
    B10000010,
    B00001000
};


const uint8_t idlePattern3[8] =
{
    B00100000,
    B00000100,
    B01000001,
    B00010000,
    B10000010,
    B00001000,
    B00100000,
    B00000101
};


const uint8_t idlePattern4[8] =
{
    B00001000,
    B10000000,
    B00100010,
    B00000100,
    B01000000,
    B00010001,
    B00000010,
    B10001000
};


// ============================================================
// FUNCTION PROTOTYPES
// ============================================================

// ---------- 8x8 MATRIX ----------

void updateAnimation();
void startNewMode();
void selectNextMode();

void drawIdlePattern();
void drawDataFlow();
void drawScanner();
void drawSystemPulse();
void drawDataBurst();

void drawBitmapPattern(
    const uint8_t pattern[8]
);


// ---------- WS2812 ----------

void updateNeoPixels();

void updateIdleLEDs();
void updateDataFlowLEDs();
void updateScannerLEDs();
void updateSystemPulseLEDs();
void updateDataBurstLEDs();

void clearNeoPixels();

uint8_t getWsAnimationSpeed(
    AnimationMode mode
);

uint8_t smoothPulse(
    uint32_t time,
    uint32_t period
);

uint8_t scaleBrightness(
    uint8_t value
);

uint32_t colorBlue();
uint32_t colorRed();
uint32_t colorGreen();
uint32_t colorOrange();


// ---------- TFT ----------

void bootTacticalDisplay();

void blinkRadarOn(
    int speed,
    int durationMs
);

void writeRadarOn(
    int letterSpeed,
    int wordSpeed,
    uint16_t color
);

void blinkObject(
    int nbr,
    uint16_t originalColor,
    uint16_t newColor,
    int durationMs,
    int speed
);

void blinkArc(
    const int arc[],
    uint16_t originalColor,
    uint16_t newColor,
    int durationMs,
    int speed
);

void blinkTacticalText(
    char *s,
    int line,
    int durationMs,
    int speed
);


// ---------- GEOMETRY ----------

void drawLineAtAngle(
    int x,
    int y,
    int length,
    double angle,
    uint16_t color
);

void drawLineAtAngleCoord(
    const int coord[],
    uint16_t color
);

void drawRectAtAngle(
    int cx,
    int cy,
    int w,
    int h,
    int degrees,
    uint16_t color
);

void drawRectAtAngleCoord(
    const int coord[],
    uint16_t color
);

void drawArc(
    int start_degree,
    int end_degree,
    int r,
    uint16_t color
);

void drawArcWidth(
    int start_degree,
    int end_degree,
    int radius,
    int increaseWidth,
    uint16_t color
);

void drawArcWidthCoord(
    const int coord[],
    uint16_t color
);

void drawCircleCentered(
    int r,
    boolean filled,
    int increaseWidth,
    uint16_t color
);


// ---------- DISPLAY ----------

void clearScreen();

void displayAurebeshString(
    char *s,
    int line,
    int speed,
    uint16_t color
);


// ---------- COLOR ----------

uint16_t create_rgb(
    uint8_t red,
    uint8_t green,
    uint8_t blue
);


// ---------- TIMER ----------

Timer initTimer(
    unsigned long durationMS
);

boolean timeNotExpired(
    Timer time
);


// ---------- NON-BLOCKING DELAY ----------

void smartDelay(
    unsigned long duration
);


// ============================================================
// SETUP
// ============================================================

void setup()
{
    Serial.begin(115200);


    // --------------------------------------------------------
    // I2C
    // --------------------------------------------------------

    Wire.begin(
        I2C_SDA_PIN,
        I2C_SCL_PIN
    );


    // --------------------------------------------------------
    // HT16K33
    // --------------------------------------------------------

    if (!matrix.begin(MATRIX_ADDRESS))
    {
        Serial.println(
            "ERROR: HT16K33 matrix not found!"
        );

        while (true)
        {
            delay(1000);
        }
    }


    matrix.setBrightness(
        MATRIX_BRIGHTNESS
    );

    matrix.clear();
    matrix.writeDisplay();


    // --------------------------------------------------------
    // RANDOM
    // --------------------------------------------------------

    randomSeed(
        esp_random()
    );


    // --------------------------------------------------------
    // WS2812B
    // --------------------------------------------------------

    strip8.begin();
    strip5.begin();

    strip8.setBrightness(
        WS_LED_BRIGHTNESS
    );

    strip5.setBrightness(
        WS_LED_BRIGHTNESS
    );

    strip8.clear();
    strip5.clear();

    strip8.show();
    strip5.show();


    // --------------------------------------------------------
    // TFT
    // --------------------------------------------------------
    //
    // Explicit SPI pin assignment makes the physical wiring
    // independent of the Arduino board package's default SPI pins.
    //
    SPI.begin(
        TFT_SCK,
        -1,          // MISO is not used by this TFT
        TFT_MOSI,
        TFT_CS
    );

    tft.setFont(
        &Aurebesh8pt7b
    );

    tft.setTextSize(1);

    tft.begin();

    clearScreen();

    tft.setRotation(0);


    // --------------------------------------------------------
    // START MATRIX ANIMATION
    // --------------------------------------------------------

    startNewMode();


    // --------------------------------------------------------
    // TFT BOOT
    // --------------------------------------------------------

    bootTacticalDisplay();


    Serial.println(
        "R2-D2 system initialized."
    );
}


// ============================================================
// MAIN LOOP
// ============================================================

void loop()
{
    updateAnimation();


    blinkObject(
        random(1, 4),
        GC9A01A_WHITE,
        objectsColor[
            random(objectColorCount)
        ],
        5000,
        700
    );


    blinkArc(
        arcs[
            random(nbrOfArcs)
        ],
        COLOR_TACTICAL_BLUE,
        objectsColor[
            random(objectColorCount)
        ],
        5000,
        700
    );


    blinkTacticalText(
        (char *)"Alert!",
        1,
        10000,
        0
    );


    writeRadarOn(
        70,
        500,
        GC9A01A_ORANGE
    );


    blinkRadarOn(
        200,
        5000
    );
}


// ============================================================
// 8x8 ANIMATION MANAGER
// ============================================================

void updateAnimation()
{
    unsigned long now = millis();


    if (
        now - modeStartTime >=
        modeDuration
    )
    {
        selectNextMode();
    }


    if (
        now - lastFrameTime >=
        frameInterval
    )
    {
        lastFrameTime = now;


        switch (currentMode)
        {
            case AnimationMode::IDLE_PATTERN:
                drawIdlePattern();
                break;

            case AnimationMode::DATA_FLOW:
                drawDataFlow();
                break;

            case AnimationMode::SCANNER:
                drawScanner();
                break;

            case AnimationMode::SYSTEM_PULSE:
                drawSystemPulse();
                break;

            case AnimationMode::DATA_BURST:
                drawDataBurst();
                break;
        }


        animationFrame++;
    }


    // --------------------------------------------------------
    // WS2812B animation
    // --------------------------------------------------------

    if (
        now - lastLedUpdate >=
        LED_UPDATE_INTERVAL
    )
    {
        lastLedUpdate = now;

        ledAnimationTime +=
            LED_UPDATE_INTERVAL *
            getWsAnimationSpeed(currentMode);

        updateNeoPixels();
    }
}


// ============================================================
// SELECT NEXT MODE
// ============================================================

void selectNextMode()
{
    uint8_t selection =
        random(0, 100);


    if (selection < 45)
    {
        currentMode =
            AnimationMode::IDLE_PATTERN;

        modeDuration =
            random(2500, 5000);

        frameInterval =
            random(180, 320);
    }


    else if (selection < 70)
    {
        currentMode =
            AnimationMode::DATA_FLOW;

        modeDuration =
            random(1800, 3200);

        frameInterval =
            random(90, 160);
    }


    else if (selection < 82)
    {
        currentMode =
            AnimationMode::SCANNER;

        modeDuration =
            random(900, 1600);

        frameInterval = 70;
    }


    else if (selection < 94)
    {
        currentMode =
            AnimationMode::SYSTEM_PULSE;

        modeDuration =
            random(1200, 2200);

        frameInterval = 110;
    }


    else
    {
        currentMode =
            AnimationMode::DATA_BURST;

        modeDuration =
            random(600, 1200);

        frameInterval =
            random(35, 70);
    }


    startNewMode();
}


// ============================================================
// START NEW MODE
// ============================================================

void startNewMode()
{
    animationFrame = 0;

    modeStartTime =
        millis();

    lastFrameTime = 0;
}


// ============================================================
// IDLE PATTERN
// ============================================================

void drawIdlePattern()
{
    uint8_t patternNumber =
        (animationFrame / 3) % 4;


    switch (patternNumber)
    {
        case 0:
            drawBitmapPattern(idlePattern1);
            break;

        case 1:
            drawBitmapPattern(idlePattern2);
            break;

        case 2:
            drawBitmapPattern(idlePattern3);
            break;

        default:
            drawBitmapPattern(idlePattern4);
            break;
    }


    if (
        random(0, 100) < 30
    )
    {
        matrix.drawPixel(
            random(0, 8),
            random(0, 8),
            LED_ON
        );
    }


    matrix.writeDisplay();
}


// ============================================================
// DATA FLOW
// ============================================================

void drawDataFlow()
{
    matrix.clear();


    uint8_t offset =
        animationFrame % 8;


    matrix.drawPixel(
        offset,
        1,
        LED_ON
    );


    matrix.drawPixel(
        (offset + 2) % 8,
        1,
        LED_ON
    );


    matrix.drawPixel(
        7 - offset,
        3,
        LED_ON
    );


    matrix.drawPixel(
        (6 - offset + 8) % 8,
        3,
        LED_ON
    );


    matrix.drawPixel(
        (offset + 3) % 8,
        5,
        LED_ON
    );


    matrix.drawPixel(
        (offset + 5) % 8,
        6,
        LED_ON
    );


    matrix.drawPixel(
        1,
        7,
        LED_ON
    );


    matrix.drawPixel(
        6,
        0,
        LED_ON
    );


    matrix.writeDisplay();
}


// ============================================================
// SCANNER
// ============================================================

void drawScanner()
{
    matrix.clear();


    uint8_t x =
        animationFrame % 8;


    for (
        uint8_t y = 1;
        y < 7;
        y++
    )
    {
        matrix.drawPixel(
            x,
            y,
            LED_ON
        );
    }


    matrix.drawPixel(
        0,
        0,
        LED_ON
    );


    matrix.drawPixel(
        7,
        7,
        LED_ON
    );


    matrix.writeDisplay();
}


// ============================================================
// SYSTEM PULSE
// ============================================================

void drawSystemPulse()
{
    matrix.clear();


    uint8_t phase =
        animationFrame % 4;


    switch (phase)
    {
        case 0:

            matrix.drawPixel(1, 1, LED_ON);
            matrix.drawPixel(6, 1, LED_ON);
            matrix.drawPixel(3, 4, LED_ON);
            matrix.drawPixel(1, 6, LED_ON);
            matrix.drawPixel(6, 6, LED_ON);

            break;


        case 1:

            matrix.drawPixel(2, 2, LED_ON);
            matrix.drawPixel(5, 2, LED_ON);
            matrix.drawPixel(3, 3, LED_ON);
            matrix.drawPixel(4, 3, LED_ON);
            matrix.drawPixel(2, 5, LED_ON);
            matrix.drawPixel(5, 5, LED_ON);

            break;


        case 2:

            matrix.drawPixel(0, 3, LED_ON);
            matrix.drawPixel(7, 3, LED_ON);
            matrix.drawPixel(3, 1, LED_ON);
            matrix.drawPixel(4, 1, LED_ON);
            matrix.drawPixel(3, 6, LED_ON);
            matrix.drawPixel(4, 6, LED_ON);

            break;


        case 3:

            matrix.drawPixel(1, 0, LED_ON);
            matrix.drawPixel(6, 0, LED_ON);
            matrix.drawPixel(0, 5, LED_ON);
            matrix.drawPixel(7, 5, LED_ON);
            matrix.drawPixel(3, 7, LED_ON);

            break;
    }


    matrix.writeDisplay();
}


// ============================================================
// DATA BURST
// ============================================================

void drawDataBurst()
{
    matrix.clear();


    uint8_t ledCount =
        random(10, 24);


    for (
        uint8_t i = 0;
        i < ledCount;
        i++
    )
    {
        matrix.drawPixel(
            random(0, 8),
            random(0, 8),
            LED_ON
        );
    }


    uint8_t row =
        random(1, 7);


    uint8_t startX =
        random(0, 4);


    for (
        uint8_t x = startX;
        x < startX + 3;
        x++
    )
    {
        matrix.drawPixel(
            x,
            row,
            LED_ON
        );
    }


    matrix.writeDisplay();
}


// ============================================================
// DRAW BITMAP
// ============================================================

void drawBitmapPattern(
    const uint8_t pattern[8]
)
{
    matrix.clear();


    for (
        uint8_t y = 0;
        y < 8;
        y++
    )
    {
        for (
            uint8_t x = 0;
            x < 8;
            x++
        )
        {
            if (
                pattern[y] &
                (1 << (7 - x))
            )
            {
                matrix.drawPixel(
                    x,
                    y,
                    LED_ON
                );
            }
        }
    }
}


// ============================================================
// WS2812 ANIMATION SPEED SELECTOR
// ============================================================
//
// Returns the user-selected speed for the currently active
// animation mode.
//
// Higher value = faster WS2812 animation.
// Lower value  = slower WS2812 animation.
//
// This function does not change TFT or HT16K33 timing.
//
uint8_t getWsAnimationSpeed(
    AnimationMode mode
)
{
    switch (mode)
    {
        case AnimationMode::IDLE_PATTERN:
            return WS_SPEED_IDLE_PATTERN;

        case AnimationMode::DATA_FLOW:
            return WS_SPEED_DATA_FLOW;

        case AnimationMode::SCANNER:
            return WS_SPEED_SCANNER;

        case AnimationMode::SYSTEM_PULSE:
            return WS_SPEED_SYSTEM_PULSE;

        case AnimationMode::DATA_BURST:
            return WS_SPEED_DATA_BURST;

        default:
            return 5;
    }
}


// ============================================================
// WS2812 MASTER
// ============================================================

void updateNeoPixels()
{
    switch (currentMode)
    {
        case AnimationMode::IDLE_PATTERN:
            updateIdleLEDs();
            break;

        case AnimationMode::DATA_FLOW:
            updateDataFlowLEDs();
            break;

        case AnimationMode::SCANNER:
            updateScannerLEDs();
            break;

        case AnimationMode::SYSTEM_PULSE:
            updateSystemPulseLEDs();
            break;

        case AnimationMode::DATA_BURST:
            updateDataBurstLEDs();
            break;
    }


    strip8.show();
    strip5.show();
}


// ============================================================
// COLOR HELPERS
// ============================================================
//
// Only pure R2-D2 style colors are used:
//
// BLUE
// RED
// GREEN
// ORANGE
//
// Brightness is handled separately.
// ============================================================

uint8_t scaleBrightness(
    uint8_t value
)
{
    return
        ((uint16_t)value *
         WS_LED_BRIGHTNESS) / 255;
}


// ------------------------------------------------------------
// Smooth sine-like pulse
// ------------------------------------------------------------
//
// Returns 0-255.
// Uses a cosine curve instead of a linear fade.
// This makes slow fades much smoother.
// ------------------------------------------------------------

uint8_t smoothPulse(
    uint32_t time,
    uint32_t period
)
{
    uint32_t phase =
        time % period;


    float angle =
        (phase * 6.2831853f) /
        period;


    float value =
        (1.0f - cos(angle)) *
        0.5f;


    return
        (uint8_t)(
            value * 255.0f
        );
}


// ============================================================
// PURE COLORS
// ============================================================

uint32_t colorBlue()
{
    return strip8.Color(
        0,
        0,
        255
    );
}


uint32_t colorRed()
{
    return strip8.Color(
        255,
        0,
        0
    );
}


uint32_t colorGreen()
{
    return strip8.Color(
        0,
        255,
        0
    );
}


uint32_t colorOrange()
{
    return strip8.Color(
        255,
        70,
        0
    );
}


// ============================================================
// WS2812 IDLE
// ============================================================
//
// Tactical standby.
//
// WS8:
// Slow blue scanning light with a secondary blue marker.
//
// WS5:
// Three stationary blue system indicators with a slow
// smooth pulse.
//
// ============================================================

void updateIdleLEDs()
{
    strip8.clear();
    strip5.clear();


    // --------------------------------------------------------
    // WS8
    // Slow tactical blue scanner
    // --------------------------------------------------------

    const uint32_t period =
        9000;


    uint32_t phase =
        ledAnimationTime %
        period;


    float normalized =
        (float)phase /
        period;


    float position;


    if (normalized < 0.5f)
    {
        position =
            normalized * 2.0f * 7.0f;
    }
    else
    {
        position =
            (1.0f - normalized) *
            2.0f *
            7.0f;
    }


    for (
        uint8_t i = 0;
        i < WS8_COUNT;
        i++
    )
    {
        float distance =
            fabs(
                (float)i -
                position
            );


        if (distance < 0.15f)
        {
            strip8.setPixelColor(
                i,
                colorBlue()
            );
        }

        else if (distance < 1.2f)
        {
            uint8_t fade =
                (uint8_t)(
                    255.0f *
                    (1.2f - distance)
                );

            uint8_t b =
                scaleBrightness(fade);

            strip8.setPixelColor(
                i,
                strip8.Color(
                    0,
                    0,
                    b
                )
            );
        }
    }


    // --------------------------------------------------------
    // WS5
    // Slow blue status pulse
    // --------------------------------------------------------

    uint8_t pulse =
        smoothPulse(
            ledAnimationTime,
            5000
        );


    uint8_t b =
        scaleBrightness(pulse);


    for (
        uint8_t i = 0;
        i < WS5_COUNT;
        i++
    )
    {
        strip5.setPixelColor(
            i,
            strip5.Color(
                0,
                0,
                b
            )
        );
    }
}


// ============================================================
// WS2812 DATA FLOW
// ============================================================
//
// Tactical computer data transfer.
//
// WS8:
//
//     BLUE -> moving data packets
//
// WS5:
//
//     GREEN -> sequential system acknowledgement
//
// ============================================================

void updateDataFlowLEDs()
{
    strip8.clear();
    strip5.clear();


    // --------------------------------------------------------
    // WS8
    // Blue data packets
    // --------------------------------------------------------

    const uint32_t period =
        6500;


    float position =
        (float)(
            ledAnimationTime %
            period
        ) /
        period *
        8.0f;


    for (
        uint8_t i = 0;
        i < WS8_COUNT;
        i++
    )
    {
        float d =
            fabs(
                (float)i -
                position
            );


        if (d < 0.2f)
        {
            strip8.setPixelColor(
                i,
                colorBlue()
            );
        }

        else if (d < 1.2f)
        {
            uint8_t fade =
                (uint8_t)(
                    255.0f *
                    (1.2f - d)
                );


            uint8_t b =
                scaleBrightness(fade);


            strip8.setPixelColor(
                i,
                strip8.Color(
                    0,
                    0,
                    b
                )
            );
        }
    }


    // --------------------------------------------------------
    // WS5
    // Green acknowledgement sequence
    // --------------------------------------------------------

    const uint32_t stepTime =
        900;


    uint8_t active =
        (
            ledAnimationTime /
            stepTime
        ) % WS5_COUNT;


    for (
        uint8_t i = 0;
        i < WS5_COUNT;
        i++
    )
    {
        if (i == active)
        {
            strip5.setPixelColor(
                i,
                colorGreen()
            );
        }
        else
        {
            strip5.setPixelColor(
                i,
                strip5.Color(
                    0,
                    scaleBrightness(25),
                    0
                )
            );
        }
    }
}


// ============================================================
// WS2812 SCANNER
// ============================================================
//
// Tactical sensor sweep.
//
// WS8:
// Blue scanner with a sharp center and soft trail.
//
// WS5:
// Red "warning" point slowly moving across the array.
//
// ============================================================

void updateScannerLEDs()
{
    strip8.clear();
    strip5.clear();


    // --------------------------------------------------------
    // WS8
    // Slow blue scanner
    // --------------------------------------------------------

    const uint32_t period =
        7000;


    uint32_t phase =
        ledAnimationTime %
        period;


    float normalized =
        (float)phase /
        period;


    float position;


    if (normalized < 0.5f)
    {
        position =
            normalized * 2.0f * 7.0f;
    }
    else
    {
        position =
            (1.0f - normalized) *
            2.0f *
            7.0f;
    }


    for (
        uint8_t i = 0;
        i < WS8_COUNT;
        i++
    )
    {
        float d =
            fabs(
                (float)i -
                position
            );


        if (d < 0.2f)
        {
            strip8.setPixelColor(
                i,
                colorBlue()
            );
        }

        else if (d < 1.0f)
        {
            uint8_t b =
                scaleBrightness(
                    (uint8_t)(
                        255.0f *
                        (1.0f - d)
                    )
                );


            strip8.setPixelColor(
                i,
                strip8.Color(
                    0,
                    0,
                    b
                )
            );
        }
    }


    // --------------------------------------------------------
    // WS5
    // Red tactical warning
    // --------------------------------------------------------

    const uint32_t redPeriod =
        6000;


    float redPosition =
        (float)(
            ledAnimationTime %
            redPeriod
        ) /
        redPeriod *
        5.0f;


    for (
        uint8_t i = 0;
        i < WS5_COUNT;
        i++
    )
    {
        float d =
            fabs(
                (float)i -
                redPosition
            );


        if (d < 0.25f)
        {
            strip5.setPixelColor(
                i,
                colorRed()
            );
        }

        else if (d < 1.1f)
        {
            uint8_t b =
                scaleBrightness(
                    (uint8_t)(
                        255.0f *
                        (1.1f - d)
                    )
                );


            strip5.setPixelColor(
                i,
                strip5.Color(
                    b,
                    0,
                    0
                )
            );
        }
    }
}


// ============================================================
// WS2812 SYSTEM PULSE
// ============================================================
//
// R2-D2 style system activity.
//
// WS8:
// Alternating BLUE / GREEN system blocks.
//
// WS5:
// Orange system heartbeat.
//
// ============================================================

void updateSystemPulseLEDs()
{
    strip8.clear();
    strip5.clear();


    // --------------------------------------------------------
    // WS8
    // Alternating tactical groups
    // --------------------------------------------------------

    const uint32_t cycle =
        4800;


    uint8_t pulse =
        smoothPulse(
            ledAnimationTime,
            cycle
        );


    bool group =
        (
            (ledAnimationTime /
             1200) % 2
        ) == 0;


    for (
        uint8_t i = 0;
        i < WS8_COUNT;
        i++
    )
    {
        bool firstGroup =
            i < 4;


        if (
            firstGroup == group
        )
        {
            uint8_t b =
                scaleBrightness(pulse);


            if (group)
            {
                strip8.setPixelColor(
                    i,
                    strip8.Color(
                        0,
                        0,
                        b
                    )
                );
            }
            else
            {
                strip8.setPixelColor(
                    i,
                    strip8.Color(
                        0,
                        b,
                        0
                    )
                );
            }
        }
        else
        {
            uint8_t dim =
                scaleBrightness(20);


            if (group)
            {
                strip8.setPixelColor(
                    i,
                    strip8.Color(
                        0,
                        dim,
                        0
                    )
                );
            }
            else
            {
                strip8.setPixelColor(
                    i,
                    strip8.Color(
                        0,
                        0,
                        dim
                    )
                );
            }
        }
    }


    // --------------------------------------------------------
    // WS5
    // Orange heartbeat
    // --------------------------------------------------------

    uint8_t orangePulse =
        smoothPulse(
            ledAnimationTime,
            3200
        );


    uint8_t orange =
        scaleBrightness(
            orangePulse
        );


    for (
        uint8_t i = 0;
        i < WS5_COUNT;
        i++
    )
    {
        strip5.setPixelColor(
            i,
            strip5.Color(
                orange,
                (orange * 30) / 255,
                0
            )
        );
    }
}


// ============================================================
// WS2812 DATA BURST
// ============================================================
//
// Short tactical alert.
//
// This is intentionally not pure random noise.
//
// WS8:
//
//     BLUE -> ORANGE -> RED
//
// WS5:
//
//     ORANGE warning sequence
//
// ============================================================

void updateDataBurstLEDs()
{
    strip8.clear();
    strip5.clear();


    // --------------------------------------------------------
    // WS8
    // Tactical alert blocks
    // --------------------------------------------------------

    uint32_t phase =
        ledAnimationTime % 2400;


    uint8_t stage =
        phase / 600;


    uint8_t active =
        (phase / 150) % 8;


    for (
        uint8_t i = 0;
        i < WS8_COUNT;
        i++
    )
    {
        if (i == active)
        {
            if (stage == 0)
            {
                strip8.setPixelColor(
                    i,
                    colorBlue()
                );
            }

            else if (stage == 1)
            {
                strip8.setPixelColor(
                    i,
                    colorGreen()
                );
            }

            else if (stage == 2)
            {
                strip8.setPixelColor(
                    i,
                    colorOrange()
                );
            }

            else
            {
                strip8.setPixelColor(
                    i,
                    colorRed()
                );
            }
        }
    }


    // --------------------------------------------------------
    // WS5
    // Orange warning sweep
    // --------------------------------------------------------

    uint8_t warning =
        (phase / 250) %
        WS5_COUNT;


    for (
        uint8_t i = 0;
        i < WS5_COUNT;
        i++
    )
    {
        if (i == warning)
        {
            strip5.setPixelColor(
                i,
                colorOrange()
            );
        }
        else
        {
            strip5.setPixelColor(
                i,
                strip5.Color(
                    scaleBrightness(30),
                    scaleBrightness(8),
                    0
                )
            );
        }
    }
}


// ============================================================
// CLEAR WS2812
// ============================================================

void clearNeoPixels()
{
    strip8.clear();
    strip5.clear();

    strip8.show();
    strip5.show();
}


// ============================================================
// TFT BOOT
// ============================================================

void bootTacticalDisplay()
{
    drawCircleCentered(
        CENTER - 17,
        false,
        3,
        COLOR_TACTICAL_BLUE
    );


    drawCircleCentered(
        15,
        false,
        1,
        COLOR_TACTICAL_BLUE
    );


    smartDelay(200);


    for (
        int i = 0;
        i < nbrOfArcs;
        i++
    )
    {
        drawArcWidthCoord(
            arcs[i],
            COLOR_TACTICAL_BLUE
        );
    }


    for (
        int i = 0;
        i < nbrAngleLines;
        i++
    )
    {
        drawLineAtAngleCoord(
            angleLines[i],
            COLOR_TACTICAL_BLUE
        );
    }


    tft.drawFastVLine(
        CENTER,
        TFT_WIDTH,
        -TFT_WIDTH,
        COLOR_TACTICAL_BLUE
    );


    tft.drawFastVLine(
        CENTER + 1,
        TFT_WIDTH,
        -TFT_WIDTH,
        COLOR_TACTICAL_BLUE
    );


    tft.drawFastHLine(
        TFT_WIDTH,
        CENTER,
        -TFT_WIDTH,
        COLOR_TACTICAL_BLUE
    );


    tft.drawFastHLine(
        TFT_WIDTH,
        CENTER + 1,
        -TFT_WIDTH,
        COLOR_TACTICAL_BLUE
    );


    smartDelay(500);


    for (
        int i = 0;
        i < nbrDetectedObjects;
        i++
    )
    {
        drawRectAtAngleCoord(
            detectedObjects[i],
            GC9A01A_WHITE
        );


        smartDelay(10);
    }


    for (
        int i = 0;
        i < nbrUndetectedObjects;
        i++
    )
    {
        drawRectAtAngleCoord(
            undetectedObjects[i],
            GC9A01A_NORON
        );
    }


    smartDelay(500);


    writeRadarOn(
        70,
        200,
        GC9A01A_ORANGE
    );
}


// ============================================================
// TFT RADAR BLINK
// ============================================================

void blinkRadarOn(
    int speed,
    int durationMs
)
{
    Timer time =
        initTimer(durationMs);


    while (
        timeNotExpired(time)
    )
    {
        writeRadarOn(
            0,
            0,
            GC9A01A_ORANGE
        );


        smartDelay(speed);


        writeRadarOn(
            0,
            0,
            GC9A01A_BLACK
        );


        smartDelay(speed);
    }


    writeRadarOn(
        0,
        0,
        GC9A01A_ORANGE
    );
}


// ============================================================
// TFT RADAR TEXT
// ============================================================

void writeRadarOn(
    int letterSpeed,
    int wordSpeed,
    uint16_t color
)
{
    for (
        int i = 0;
        i < wordsCount;
        i++
    )
    {
        displayAurebeshString(
            (char *)WORDS[i],
            i,
            letterSpeed,
            color
        );


        smartDelay(
            wordSpeed
        );
    }
}


// ============================================================
// TFT BLINK OBJECT
// ============================================================

void blinkObject(
    int nbr,
    uint16_t originalColor,
    uint16_t newColor,
    int durationMs,
    int speed
)
{
    Timer time =
        initTimer(durationMs);


    int object[nbr];


    for (
        int i = 0;
        i < nbr;
        i++
    )
    {
        object[i] =
            random(
                nbrDetectedObjects
            );
    }


    while (
        timeNotExpired(time)
    )
    {
        for (
            int i = 0;
            i < nbr;
            i++
        )
        {
            drawRectAtAngleCoord(
                detectedObjects[
                    object[i]
                ],
                newColor
            );
        }


        smartDelay(speed);


        for (
            int i = 0;
            i < nbr;
            i++
        )
        {
            drawRectAtAngleCoord(
                detectedObjects[
                    object[i]
                ],
                originalColor
            );
        }


        smartDelay(speed);
    }
}


// ============================================================
// TFT BLINK ARC
// ============================================================

void blinkArc(
    const int arc[],
    uint16_t originalColor,
    uint16_t newColor,
    int durationMs,
    int speed
)
{
    Timer time =
        initTimer(durationMs);


    while (
        timeNotExpired(time)
    )
    {
        drawArcWidthCoord(
            arc,
            newColor
        );


        smartDelay(speed);


        drawArcWidthCoord(
            arc,
            originalColor
        );


        smartDelay(speed);
    }
}


// ============================================================
// TFT ALERT
// ============================================================

void blinkTacticalText(
    char *s,
    int line,
    int durationMs,
    int speed
)
{
    Timer time =
        initTimer(durationMs);


    int color = 0;

    int direction = 8;


    writeRadarOn(
        0,
        0,
        GC9A01A_BLACK
    );


    while (
        timeNotExpired(time)
    )
    {
        tft.setCursor(
            TEXT_LINES[line][0],
            TEXT_LINES[line][1]
        );


        tft.setTextColor(
            create_rgb(
                color,
                0,
                0
            )
        );


        tft.print(s);


        color += direction;


        if (color >= 255)
        {
            color = 255;
            direction = -8;
        }


        if (color < 0)
        {
            color = 0;
            direction = 8;
        }


        updateAnimation();

        delay(1);
    }


    tft.setCursor(
        TEXT_LINES[line][0],
        TEXT_LINES[line][1]
    );


    tft.setTextColor(
        GC9A01A_BLACK
    );


    tft.print(s);
}


// ============================================================
// GEOMETRY
// ============================================================

void drawLineAtAngle(
    int x,
    int y,
    int length,
    double angle,
    uint16_t color
)
{
    double radians =
        angle * M_PI / 180.0;


    int x2 =
        x +
        length *
        cos(radians);


    int y2 =
        y +
        length *
        sin(radians);


    tft.drawLine(
        x,
        y,
        x2,
        y2,
        color
    );
}


// ============================================================

void drawLineAtAngleCoord(
    const int coord[],
    uint16_t color
)
{
    drawLineAtAngle(
        coord[0],
        coord[1],
        coord[2],
        coord[3],
        color
    );
}


// ============================================================
// ROTATED RECTANGLE
// ============================================================

void drawRectAtAngle(
    int cx,
    int cy,
    int w,
    int h,
    int degrees,
    uint16_t color
)
{
    double radians =
        degrees * M_PI / 180.0;


    double sinRad =
        sin(radians);


    double cosRad =
        cos(radians);


    double w2 =
        w / 2;


    double h2 =
        h / 2;


    for (
        int i = 0;
        i < h;
        i++
    )
    {
        for (
            int j = 0;
            j < w;
            j++
        )
        {
            int x1 =
                cx +
                j -
                w2;


            int y1 =
                cy +
                i -
                h2;


            int x1cx =
                x1 -
                cx;


            int y1cy =
                y1 -
                cy;


            int x2 =
                cx +
                x1cx *
                cosRad -
                y1cy *
                sinRad;


            int y2 =
                cy +
                x1cx *
                sinRad +
                y1cy *
                cosRad;


            tft.drawPixel(
                x2,
                y2,
                color
            );
        }
    }
}


// ============================================================

void drawRectAtAngleCoord(
    const int coord[],
    uint16_t color
)
{
    drawRectAtAngle(
        coord[0],
        coord[1],
        coord[2],
        coord[3],
        coord[4],
        color
    );
}


// ============================================================
// ARC
// ============================================================

void drawArc(
    int start_degree,
    int end_degree,
    int r,
    uint16_t color
)
{
    Coordinate pixel_coordinates[
        num_degrees
    ];


    for (
        int i = 0;
        i < num_degrees;
        i++
    )
    {
        pixel_coordinates[i].x =
            CENTER +
            r *
            cos(
                i *
                M_PI /
                180.0
            );


        pixel_coordinates[i].y =
            CENTER +
            r *
            sin(
                i *
                M_PI /
                180.0
            );
    }


    for (
        int i = start_degree;
        i <= end_degree;
        i++
    )
    {
        tft.drawPixel(
            pixel_coordinates[i].x,
            pixel_coordinates[i].y,
            color
        );
    }
}


// ============================================================
// ARC WIDTH
// ============================================================

void drawArcWidth(
    int start_degree,
    int end_degree,
    int radius,
    int increaseWidth,
    uint16_t color
)
{
    for (
        int i = -increaseWidth;
        i <= increaseWidth;
        i++
    )
    {
        drawArc(
            start_degree,
            end_degree,
            radius + i,
            color
        );
    }
}


// ============================================================

void drawArcWidthCoord(
    const int coord[],
    uint16_t color
)
{
    drawArcWidth(
        coord[0],
        coord[1],
        coord[2],
        coord[3],
        color
    );
}


// ============================================================
// CIRCLE
// ============================================================

void drawCircleCentered(
    int r,
    boolean filled,
    int increaseWidth,
    uint16_t color
)
{
    if (filled)
    {
        tft.fillCircle(
            CENTER,
            CENTER,
            r,
            color
        );
    }
    else
    {
        for (
            int i = -increaseWidth;
            i <= increaseWidth;
            i++
        )
        {
            tft.drawCircle(
                CENTER,
                CENTER,
                r + i,
                color
            );
        }
    }
}


// ============================================================
// CLEAR TFT
// ============================================================

void clearScreen()
{
    tft.fillScreen(
        GC9A01A_BLACK
    );
}


// ============================================================
// AUREBESH
// ============================================================

void displayAurebeshString(
    char *s,
    int line,
    int speed,
    uint16_t color
)
{
    tft.setCursor(
        TEXT_LINES[line][0],
        TEXT_LINES[line][1]
    );


    tft.setTextColor(
        color
    );


    for (
        int i = 0;
        i < strlen(s);
        i++
    )
    {
        tft.print(
            s[i]
        );


        if (speed > 0)
        {
            smartDelay(speed);
        }
    }
}


// ============================================================
// RGB
// ============================================================

uint16_t create_rgb(
    uint8_t red,
    uint8_t green,
    uint8_t blue
)
{
    return
        ((red & 0b11111000) << 8) |
        ((green & 0b11111100) << 3) |
        (blue >> 3);
}


// ============================================================
// TIMER
// ============================================================

Timer initTimer(
    unsigned long durationMS
)
{
    Timer timer =
    {
        millis(),
        durationMS
    };


    return timer;
}


// ============================================================

boolean timeNotExpired(
    Timer time
)
{
    return
        millis() -
        time.time_start <
        time.durationMs;
}


// ============================================================
// SMART DELAY
// ============================================================

void smartDelay(
    unsigned long duration
)
{
    unsigned long start =
        millis();


    while (
        millis() - start <
        duration
    )
    {
        updateAnimation();

        delay(1);
    }
}
